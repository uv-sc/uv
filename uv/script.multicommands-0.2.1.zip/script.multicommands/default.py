# -*- coding: utf-8 -*-
"""
Default entry for script.remote.multicommand

If started while a video is playing, open the overlay.
If started from Program add-ons (no video), present a menu with
options to install the remote keymap, backup commands.json, or
restore a commands.json from any location chosen by the user.
All user-visible strings are in English.
"""

import os
import shutil

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from overlay import show_overlay

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
RES_PATH = os.path.join(ADDON_PATH, 'resources')
GLOBAL_WINDOW = xbmcgui.Window(10000)
PROP_ACTIVE = 'RemoteMultiCommand.Active'
PROP_CLOSE = 'RemoteMultiCommand.CloseRequested'


def _overlay_active():
    return GLOBAL_WINDOW.getProperty(PROP_ACTIVE) == '1'


def _request_overlay_close():
    GLOBAL_WINDOW.setProperty(PROP_CLOSE, '1')


def _notify(title, message, time=3000):
    xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, time)


def install_keymap():
    """Prompt user to press a remote button, capture its code, update the
    keymap XML (replace example id) and copy it to userdata/keymaps/.
    """
    import re
    import time

    # Confirm with the user before starting capture
    proceed = xbmcgui.Dialog().yesno(
        'Remote MultiCommand',
        'This will ask you to press a remote button to use as the trigger.\n\nPress YES to continue or NO to cancel.')
    if not proceed:
        return

    # Small window to capture the button press
    class KeyCaptureWindow(xbmcgui.WindowDialog):
        def __init__(self):
            super(KeyCaptureWindow, self).__init__()
            self.code = None
            self._running = True
            # Instruction label
            try:
                self._label = xbmcgui.ControlLabel(100, 100, 1100, 60,
                                                   'Press the desired remote button now (or press Back to cancel)')
                self.addControl(self._label)
            except Exception:
                pass

        def run(self, timeout=15):
            start = time.time()
            self.show()
            monitor = xbmc.Monitor()
            while self._running and (time.time() - start) < timeout and not monitor.abortRequested():
                xbmc.sleep(50)
            self.close()

        def onAction(self, action):
            # Prefer buttonCode if available; fall back to action id
            try:
                bcode = action.getButtonCode()
                aid = action.getId()
            except Exception:
                bcode = None
                aid = None
            if bcode and bcode != 0:
                self.code = int(bcode)
            elif aid and aid != 0:
                self.code = int(aid)
            else:
                self.code = None
            self._running = False

    # Run capture
    win = KeyCaptureWindow()
    win.run(timeout=15)
    detected = win.code
    del win

    if not detected:
        xbmcgui.Dialog().ok('Remote MultiCommand', 'No button detected — installation cancelled.')
        return

    # Read template keymap XML and replace the key id (first numeric id shown)
    src = os.path.join(RES_PATH, 'remote_multicommand_keymap.xml')
    try:
        with open(src, 'r', encoding='utf-8') as f:
            xml = f.read()
    except Exception as e:
        xbmc.log('[MultiCommand] cannot read keymap template: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Remote MultiCommand', 'Failed to read keymap template:\n{}'.format(e))
        return

    # Replace the first occurrence of id="NUMBER" inside the <remote> section
    new_xml, n = re.subn(r'id="\d+"', 'id="{}"'.format(detected), xml, count=1)
    if n == 0:
        # Fallback: append a key line (shouldn't normally happen)
        xbmc.log('[MultiCommand] failed to replace id in XML; using original file', xbmc.LOGWARNING)
        new_xml = xml

    # Ensure destination directory
    dst_dir = xbmcvfs.translatePath('special://profile/keymaps/')
    try:
        if not os.path.isdir(dst_dir):
            os.makedirs(dst_dir)
    except Exception:
        # Not fatal; will try to copy and let shutil raise
        pass

    dst = os.path.join(dst_dir, 'remote_multicommand_keymap.xml')
    try:
        # Write the modified keymap to a temp file then copy
        temp_path = os.path.join(xbmcvfs.translatePath('special://temp/'), 'remote_multicommand_keymap.xml')
        with open(temp_path, 'w', encoding='utf-8') as f:
            f.write(new_xml)
        shutil.copy2(temp_path, dst)
        # Attempt to reload keyboard layouts so the new keymap takes effect
        try:
            xbmc.executebuiltin("action(reloadkeymaps)")
        except Exception as e:
            xbmc.log('[MultiCommand] reload keymap builtins failed: {}'.format(e), xbmc.LOGWARNING)
        # Notify user and advise manual reload if needed
        _notify('Remote MultiCommand', 'Keymap installed to userdata/keymaps.\nDetected code: {}'.format(detected))
        xbmcgui.Dialog().ok('Remote MultiCommand', 'Keymap installed.[CR]If the remote button does not work, restart Kodi.')
    except Exception as e:
        xbmc.log('[MultiCommand] install_keymap failed: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Remote MultiCommand', 'Failed to install keymap:\n{}'.format(e))


def backup_commands():
    """Copy resources/commands.json to a user-selected folder as commands.json.

    If the user cancels the dialogs, do nothing. Some Kodi skins disable OK on
    the folder picker; fall back to letting the user pick any file inside the
    desired folder and use its parent. If the user cancels both, abort.
    """
    src = os.path.join(RES_PATH, 'commands.json')

    dest_folder = None
    file_pick = xbmcgui.Dialog().browse(0, 'Select a file in the destination folder (or Cancel to abort)', 'special://home/', '*.json')
    if file_pick:
        dest_folder = os.path.dirname(file_pick)

    # If still no folder, user cancelled -> do nothing
    if not dest_folder:
        return

    try:
        if not os.path.isdir(dest_folder):
            os.makedirs(dest_folder)
        dst = os.path.join(dest_folder, 'commands.json')
        shutil.copy2(src, dst)
        _notify('Remote MultiCommand', 'Backup saved: {}'.format(dst))
    except Exception as e:
        xbmc.log('[MultiCommand] backup_commands failed: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Remote MultiCommand', 'Backup failed:\n{}'.format(e))


def restore_commands_from_anywhere():
    """Restore resources/commands.json from a user-selected file.
    The current resources/commands.json is renamed to commands.json.bak
    inside the resources folder before the restore.
    """
    # Ask user to select a source file
    candidate = xbmcgui.Dialog().browse(1, 'Select commands.json to restore', 'special://home/', '.json')
    if not candidate:
        return
    res_file = os.path.join(RES_PATH, 'commands.json')
    try:
        if not os.path.isfile(candidate):
            xbmcgui.Dialog().ok('Remote MultiCommand', 'Selected file does not exist:\n{}'.format(candidate))
            return
        # rename current resources/commands.json to commands.json.bak
        if os.path.isfile(res_file):
            bak = os.path.join(RES_PATH, 'commands.json.bak')
            try:
                if os.path.isfile(bak):
                    os.remove(bak)
                os.rename(res_file, bak)
            except Exception as e:
                xbmc.log('[MultiCommand] failed to backup current commands.json: {}'.format(e), xbmc.LOGWARNING)
        # copy candidate into resources
        shutil.copy2(candidate, res_file)
        _notify('Remote MultiCommand', 'commands.json restored from: {}'.format(candidate))
    except Exception as e:
        xbmc.log('[MultiCommand] restore_commands failed: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Remote MultiCommand', 'Restore failed:\n{}'.format(e))


if xbmc.Player().isPlaying() and xbmc.getCondVisibility('Player.HasVideo'):
    if _overlay_active():
        _request_overlay_close()
    else:
        show_overlay()
else:
    # Menu shown when launched from Program add-ons (no video playing)
    choices = [
        # 'Open overlay (requires a playing video)',
        'Install remote keymap -> userdata/keymaps',
        'Backup commands.json',
        'Restore commands.json',
        'Cancel'
    ]
    sel = xbmcgui.Dialog().select('Remote MultiCommand — Menu', choices)
    if sel == 0:
        install_keymap()
    elif sel == 1:
        backup_commands()
    elif sel == 2:
        restore_commands_from_anywhere()
    else:
        # Cancel / closed
        pass
