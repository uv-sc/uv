# -*- coding: utf-8 -*-
"""
script.remote.multicommand — overlay window

Commands are read from resources/commands.json.
The RC image is displayed over the video (no scrim, video stays visible).
Text labels are placed under each button based on image geometry.

commands.json schema (per set, per slot):
    "command" : Kodi built-in, seek(±s), script.py, or bare action name
    "name"    : display label (max 9 chars shown)
    "close"   : true = close overlay after executing, false = stay open

EXIT key cycles through all sets; pressing EXIT on the last set closes.
"""

import json
import os
import re
import struct
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# ── Paths ─────────────────────────────────────────────────────────────────────
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
RES_PATH = os.path.join(ADDON_PATH, 'resources')
MEDIA_PATH = os.path.join(RES_PATH, 'media')
SCRIPTS_PATH = os.path.join(RES_PATH, 'scripts')
GLOBAL_WINDOW = xbmcgui.Window(10000)
PROP_ACTIVE = 'RemoteMultiCommand.Active'
PROP_CLOSE = 'RemoteMultiCommand.CloseRequested'


# def _cache(filename):
#     """Copy a media file to special://temp/ once; return its absolute path."""
#     dst = os.path.join(TEMP_DIR, 'mc_' + filename)
#     if not os.path.isfile(dst):
#         shutil.copy2(os.path.join(MEDIA_PATH, filename), dst)
#     return dst


def _png_size(path):
    """Read PNG width/height from file header without external libraries."""
    try:
        with open(path, 'rb') as f:
            f.read(16)                              # sig (8) + IHDR tag+len (8)
            w = struct.unpack('>I', f.read(4))[0]
            h = struct.unpack('>I', f.read(4))[0]
        return w, h
    except Exception:
        return 303, 487                             # fallback to known rc.png size


def _set_overlay_active(active):
    if active:
        GLOBAL_WINDOW.setProperty(PROP_ACTIVE, '1')
    else:
        GLOBAL_WINDOW.clearProperty(PROP_ACTIVE)
        GLOBAL_WINDOW.clearProperty(PROP_CLOSE)


def _overlay_active():
    return GLOBAL_WINDOW.getProperty(PROP_ACTIVE) == '1'


def _request_overlay_close():
    GLOBAL_WINDOW.setProperty(PROP_CLOSE, '1')


# ── Command loading ───────────────────────────────────────────────────────────
def _load_commands():
    """
    Parse resources/commands.json.
    Returns {set_number (int): {slot: {command, name, close}}}
    """
    path = os.path.join(RES_PATH, 'commands.json')
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    # JSON requires string keys; convert to int for ordered set numbering
    return {int(k): v for k, v in data.items()}


# ── Screen & image layout ─────────────────────────────────────────────────────
SW, SH = 1280, 720

# RC image display size: scale to IMG_H tall, preserve aspect ratio.
# Positioned on the right side so most of the video remains visible.
IMG_H = 560
IMG_H = 400
RC_ORIG = _png_size(os.path.join(MEDIA_PATH, 'rc.png'))   # (303, 487)
IMG_W = int(RC_ORIG[0] * IMG_H / RC_ORIG[1])            # ≈ 348
IMG_X = SW - IMG_W - 20
IMG_Y = (SH - IMG_H) // 2 - 100

# Button visual centres as fractions of the original image (width, height).
# Calibrated against the 303×487 rc.png.

BUTTON_POS = {
    'up': (0.500, 0.065),
    'left': (0.22, 0.235),
    'ok': (0.500, 0.147),
    'right': (0.78, 0.235),
    'down': (0.500, 0.40),
    'exit': (0.248, 0.668),
    'chup': (0.745, 0.56),
    'chdn': (0.745, 0.72),
}

LABEL_W = 110    # px — label control width (centred on button x)
LABEL_H = 22    # px — label control height
LABEL_OFFSET = 38    # px below button centre → label top edge
MAX_LABEL = 20     # maximum characters shown in a label

# Set indicator: small pill shown above the image
INDICATOR_W = IMG_W
INDICATOR_H = 24
INDICATOR_X = IMG_X
INDICATOR_Y = IMG_Y - INDICATOR_H - 6

# ── Colours (AARRGGBB) ────────────────────────────────────────────────────────
C_WHITE = '0xFFFFFFFF'
C_HINT = '0xCCCCCCCC'
C_INDICATOR = '0xDD151520'
C_ACCENT = '0xFF2979FF'

SLOT_COLOUR = {
    'up': '0xFF81C784',
    'left': '0xFFFFCC80',
    'ok': '0xFFEF9A9A',
    'right': '0xFFFFCC80',
    'down': '0xFF81C784',
    'exit': '0xFF888888',
    'chup': '0xFF90CAF9',
    'chdn': '0xFF90CAF9',
}

# ── Kodi action ID → slot ─────────────────────────────────────────────────────
ACTION_MAP = {
    1: 'left', 2: 'right', 3: 'up', 4: 'down',
    7: 'ok', 9: 'exit', 10: 'exit',
    5: 'chup', 6: 'chdn',
}


def _configured_toggle_keys():
    """Return the key codes configured for the overlay trigger in the keymap."""
    keys = set()
    keymap_path = os.path.join(xbmcvfs.translatePath('special://profile/keymaps/'),
                               'remote_multicommand_keymap.xml')
    try:
        root = ET.parse(keymap_path).getroot()
        for elem in root.iter():
            if elem.tag.lower() == 'key':
                val = elem.attrib.get('id')
                if val:
                    try:
                        keys.add(int(val))
                    except ValueError:
                        pass
            elif elem.tag.lower() in ('f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9', 'f10', 'f11', 'f12'):
                keys.add(int(elem.tag.lower()[1:]))
    except Exception:
        pass
    # Default fallback keys for keyboard testing and standard template.
    keys.update({50, 111})
    return keys


# ── Viewmode actions → silent JSON-RPC (no OSD slider) ───────────────────────
VIEWMODE_ACTIONS = {
    'verticalshiftup': ('verticalshift', -0.01),
    'verticalshiftdown': ('verticalshift', +0.01),
    'zoomin': ('zoom', +0.01),
    'zoomout': ('zoom', -0.01),
    'zoomnormal': None,
}
VIEWMODE_RESET = {
    'zoom': 1.0, 'pixelratio': 1.0,
    'verticalshift': 0.0, 'stretch': False, 'nonlinearstretch': False,
}

_SEEK_RE = re.compile(r'^seek\(([+-]?\d+)\)$', re.IGNORECASE)


# ── Helpers ───────────────────────────────────────────────────────────────────
def _jsonrpc(method, params=None):
    req = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        req['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(req)))


def _unwrap(cmd):
    """
    Extract the bare inner name from any Kodi wrapper:
      Action(name)           → name (lowercased)
      ActivateWindow(name)   → name (lowercased)
      XBMC.name              → name (lowercased)
      name                   → name (lowercased)
    """
    s = cmd.strip()
    paren = s.find('(')
    if paren != -1 and s.endswith(')'):
        return s[paren + 1:-1].strip().lower()
    dot = s.find('.')
    if dot != -1:
        return s[dot + 1:].strip().lower()
    return s.lower()


def _exec(cmd):
    """
    Execute a command string. Handles (in priority order):
      1. Python scripts (.py)  → RunScript(addon_scripts_path/script.py)
      2. seek(±seconds)        → xbmc.Player().seekTime()
      3. Viewmode actions      → Player.SetViewMode via JSON-RPC (no OSD)
      4. Everything else       → xbmc.executebuiltin()
    """
    xbmc.log('[MultiCommand] exec: {}'.format(cmd), xbmc.LOGINFO)

    # 1. Python script in resources/scripts/
    if cmd.strip().lower().endswith('.py'):
        script = os.path.join(SCRIPTS_PATH, cmd.strip())
        xbmc.executebuiltin('RunScript({})'.format(script))
        # Wait for the script and any overlay it opens to finish
        xbmc.sleep(500)
        return

    # 2. Seek relative to current position: seek(±seconds)
    m = _SEEK_RE.match(cmd.strip())
    if m:
        seconds = int(m.group(1))
        player = xbmc.Player()
        if player.isPlaying():
            player.seekTime(max(0.0, player.getTime() + seconds))
        return

    # 3. Viewmode actions routed through JSON-RPC to suppress OSD
    action_name = _unwrap(cmd)
    if action_name in VIEWMODE_ACTIONS:
        delta_info = VIEWMODE_ACTIONS[action_name]
        if delta_info is None:
            _jsonrpc('Player.SetViewMode', {'viewmode': VIEWMODE_RESET})
        else:
            field, delta = delta_info
            current = _jsonrpc('Player.GetViewMode').get('result', {})
            new_val = round(current.get(field, 0.0) + delta, 4)
            _jsonrpc('Player.SetViewMode', {'viewmode': {field: new_val}})
        return

    # 4. Standard Kodi built-in
    xbmc.executebuiltin(cmd)


def _button_label_pos(slot):
    """
    Return (x, y) for the top-left corner of the label ControlLabel
    for the given slot, in absolute screen coordinates.
    x is chosen so the label is centred under the button.
    """
    fx, fy = BUTTON_POS[slot]
    bx = IMG_X + int(fx * IMG_W)
    by = IMG_Y + int(fy * IMG_H)
    return bx - LABEL_W // 2, by + LABEL_OFFSET


# ── Overlay window ────────────────────────────────────────────────────────────
class RemoteOverlay(xbmcgui.WindowDialog):

    def __init__(self, rc_path, white_path):
        super(RemoteOverlay, self).__init__()
        self._rc = rc_path
        self._white = white_path
        self._running = True
        self._cur_set = 1
        self._toggle_keys = _configured_toggle_keys()
        self._sets = _load_commands()  # {int: {slot: entry}}
        self._num_sets = max(self._sets.keys())
        self._lbl_ctrls = {}  # slot → ControlLabel for live caption updates
        self._ind_ctrl = None  # set indicator label
        self._build_ui()

    @property
    def _commands(self):
        return self._sets.get(self._cur_set, {})

    # ── UI ────────────────────────────────────────────────────────────────────

    def _img(self, x, y, w, h, path, colour=None):
        ctrl = xbmcgui.ControlImage(x, y, w, h, path)
        if colour:
            ctrl.setColorDiffuse(colour)
        self.addControl(ctrl)
        return ctrl

    def _lbl(self, x, y, w, h, text, colour, font='font10', align=2):
        ctrl = xbmcgui.ControlLabel(
            x, y, w, h, text, font=font, textColor=colour, alignment=align)
        self.addControl(ctrl)
        return ctrl

    def _indicator_text(self):
        return 'Set  {} / {}'.format(self._cur_set, self._num_sets)

    def _slot_label(self, slot):
        """Return display label for slot (max MAX_LABEL chars)."""
        entry = self._commands.get(slot, {})
        name = entry.get('name', '') if entry else ''
        return name[:MAX_LABEL]

    def _build_ui(self):
        # RC image (no scrim — video visible behind)
        self._img(IMG_X, IMG_Y, IMG_W, IMG_H, self._rc)

        # Set indicator pill above image
        self._img(INDICATOR_X, INDICATOR_Y, INDICATOR_W, INDICATOR_H,
                  self._white, C_INDICATOR)
        self._ind_ctrl = self._lbl(
            INDICATOR_X, INDICATOR_Y, INDICATOR_W, INDICATOR_H,
            self._indicator_text(), C_ACCENT, font='font12', align=2)

        # Per-button labels
        for slot in BUTTON_POS:
            lx, ly = _button_label_pos(slot)
            colour = SLOT_COLOUR.get(slot, C_HINT)
            text = self._slot_label(slot)
            # xbmc.log('[MultiCommand] label for slot "{}": "{}"'.format(slot, text), xbmc.LOGINFO)
            ctrl = self._lbl(lx, ly, LABEL_W, LABEL_H, text, colour)
            self._lbl_ctrls[slot] = ctrl

    def _refresh(self):
        """Update indicator and all button labels after a set change."""
        self._ind_ctrl.setLabel(self._indicator_text())
        for slot, ctrl in self._lbl_ctrls.items():
            ctrl.setLabel(self._slot_label(slot))

    # ── Event loop ────────────────────────────────────────────────────────────

    def run(self):
        xbmc.log('[MultiCommand] open set={}/{}'.format(
                 self._cur_set, self._num_sets), xbmc.LOGINFO)
        _set_overlay_active(True)
        self.show()
        monitor = xbmc.Monitor()
        while self._running and not monitor.abortRequested():
            if GLOBAL_WINDOW.getProperty(PROP_CLOSE) == '1':
                xbmc.log('[MultiCommand] close requested by trigger key, closing overlay', xbmc.LOGINFO)
                self._running = False
                break

            try:
                player = xbmc.Player()
                if not player.isPlayingVideo():
                    xbmc.log('[MultiCommand] playback stopped, closing overlay', xbmc.LOGINFO)
                    self._running = False
                    break
            except Exception:
                pass

            # Try to keep focus on this window by calling show() periodically
            # This helps re-display the overlay if it was hidden by Kodi dialogs
            try:
                self.show()
            except Exception:
                pass
            xbmc.sleep(100)
        self.close()
        _set_overlay_active(False)
        xbmc.log('[MultiCommand] closed', xbmc.LOGINFO)

    def onAction(self, action):
        aid = action.getId()
        bcode = action.getButtonCode()
        xbmc.log('[MultiCommand] action={} btn={} set={}'.format(
                 aid, bcode, self._cur_set), xbmc.LOGDEBUG)

        if aid in self._toggle_keys or bcode in self._toggle_keys:
            xbmc.log('[MultiCommand] same trigger key pressed; closing overlay', xbmc.LOGINFO)
            self._running = False
            return

        slot = ACTION_MAP.get(aid)

        # EXIT: cycle sets or close
        if slot == 'exit' or aid in (9, 10, 92):
            if self._cur_set < self._num_sets:
                self._cur_set += 1
                self._refresh()
            else:
                self._running = False
            return

        if slot and slot in self._commands:
            entry = self._commands[slot]
            cmd = entry['command']
            # Screenshot must happen with the overlay hidden; otherwise Kodi
            # captures the add-on UI as part of the image.
            if _unwrap(cmd) == 'screenshot' and entry.get('close', False):
                self._running = False
                self.close()
                xbmc.sleep(50)
            _exec(cmd)
            if entry.get('close', False):  # or _unwrap(cmd) == 'screenshot':
                self._running = False
                self.close()


# ── Entry point ───────────────────────────────────────────────────────────────
def show_overlay():
    if _overlay_active():
        _request_overlay_close()
        return

    _set_overlay_active(True)
    win = RemoteOverlay(os.path.join(MEDIA_PATH, 'rc.png'), os.path.join(MEDIA_PATH, 'white.png'))
    win.run()
    del win
