import xbmc

xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
xbmc.executebuiltin("Action(SubtitleDelayMinus)")
