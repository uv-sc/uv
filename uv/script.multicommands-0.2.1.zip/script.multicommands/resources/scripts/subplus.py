import xbmc

xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
xbmc.executebuiltin("Action(SubtitleDelayPlus)")
