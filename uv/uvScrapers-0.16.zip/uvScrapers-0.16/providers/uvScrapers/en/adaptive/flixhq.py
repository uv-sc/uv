# -*- coding: utf-8 -*-
import re
import requests
import time
# import html
import json
import unicodedata
# from urllib.parse import quote
import xbmcgui
# import xbmcvfs
# import os
# import base64

from resources.lib.common.source_utils import (clean_title,)
from resources.lib.modules.exceptions import PreemptiveCancellation
from providerModules.uvScrapers import common

try:
    from providerModules.uvScrapers.pyaes import openssl_aes
except Exception as error:
    common.log(error)


class sources:
    def __init__(self):
        self.base_hdrs = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
            'Accept-Encoding': 'gzip',
            'Accept-Language': 'en-US,en;q=0.8',
            'Connection': 'keep-alive'
        }

        self.language = ["en"]
        self.base_link = "https://flixhq.to/"
        self.search_link = "search/"
        self.query_link = f"{self.base_link}{self.search_link}"
        self.start_time = 0
        self.subs = []

    def _return_results(self, source_type, sources, preemptive=False):
        if preemptive:
            common.log(f"uvScrapers.{source_type}.flixhq: cancellation requested", "info",)
        elif preemptive is None:
            common.log(f"uvScrapers.{source_type}.flixhq: not authorized", "info",)

        common.log(f"uvScrapers.{source_type}.flixhq: {len(sources)}", "info")
        common.log(f"uvScrapers.{source_type}.flixhq: took {int((time.time() - self.start_time) * 1000)} ms", "info",)
        return sources

    def _make_query(self, query, year, type):
        common.log('Query: ' + query + ' year: ' + str(year) + ' type: ' + type)
        query = "".join([c for c in unicodedata.normalize("NFKD", query) if unicodedata.category(c) != "Mn"])

        queryurl = self.query_link + query
        common.log('Query URL: ' + queryurl)
        queryurl = queryurl.replace('%', '')
        listhtml = requests.get(queryurl).text

        videos = listhtml.split('<div class="flw-item">')
        videos.pop(0)
        common.log('len(videos): ' + str(len(videos)))
        results = []

        for video in videos:
            match = re.search(r'<a\s+href="/([^"]+)"', video, flags=re.DOTALL | re.IGNORECASE)
            if match:
                videourl = self.base_link + match.group(1)
                common.log('videourl: ' + videourl)
            else:
                continue

            match = re.search(r'<span class="fdi-item">(\d+)</span>', video, flags=re.DOTALL | re.IGNORECASE)
            qyear = match.group(1) if match else ''
            common.log('qyear: ' + qyear + ' year: ' + str(year))
            if (year != 'None') and (qyear != '') and str(qyear) != str(year):
                common.log('YEAR')
                continue

            match = re.search('fdi-type">([^<]+)<', video, flags=re.DOTALL | re.IGNORECASE)
            qtype = match.group(1) if match else ''
            common.log('qtype: ' + qtype + ' type: ' + type)
            if qtype != type:
                continue

            match = re.search('title="([^"]+)"', video, flags=re.DOTALL | re.IGNORECASE)
            title = common.cleantext(match.group(1)) if match else ''
            results.append({'title': title, 'year': year, 'videourl': videourl})

            title = clean_title(title).replace(' ', '-')
            common.log(title)
            if title == query:
                break

        common.log(f"uvScrapers.flixhq: MAKE QUERY END {int((time.time() - self.start_time) * 1000)} ms", "info",)
        common.log(results)
        return results

    def _process_item(self, item, simple_info):
        season = simple_info.get('season_number')
        episode = simple_info.get('episode_number')
        common.log('season: ' + str(season) + ' episode: ' + str(episode))
        url = item['videourl']
        id = url.split('-')[-1]
        common.log('video id: ' + id)

        if season:
            seasonsurl = self.base_link + 'ajax/season/list/' + id
            common.log('seasonsurl: ' + seasonsurl)
            seasonshtml = requests.get(seasonsurl).text
            match = re.compile(rf'href="#ss-episodes-(\d+)">Season\s*{season}', re.DOTALL | re.IGNORECASE).findall(seasonshtml)
            if not match:
                return
            seasonid = match[0]
            common.log('seasonid: ' + seasonid)
            season = f'S{season}'

            episodeurl = self.base_link + 'ajax/v2/season/episodes/' + seasonid
            common.log('episodeurl: ' + episodeurl)
            episodehtml = requests.get(episodeurl).text
            match = re.compile(rf'data-id="(\d+)"[^>]+?title="Eps\s*0*{episode}', re.DOTALL | re.IGNORECASE).findall(episodehtml)

            if not match:
                return
            id = match[0]
            common.log('server id: ' + str(match[0]))

        serverurl = self.base_link + 'ajax/episode/list/' + id if '/movie/' in url else self.base_link + 'ajax/episode/servers/' + id
        common.log('serverurl: ' + serverurl)
        serverhtml = requests.get(serverurl).text

        match = re.compile(r'data-id="(\d+)".+?<span>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(serverhtml)
        common.log('match: ' + str(match))
        if not match:
            return

        source = []
        self.subs = []

        for serverid, servername in match:
            common.log('servername: ' + servername + ' serverid: ' + serverid)
            if servername not in ('UpCloud', 'MegaCloud', 'Vidcloud', 'AKCloud'):
                common.log(f"Skipping server: {servername}", "info")
                continue

            srcurl = self.base_link + 'ajax/episode/sources/' + serverid
            common.log('srcurl: ' + srcurl)
            srchtml = requests.get(srcurl).text

            match = re.compile('"link":"([^"]+)"').search(srchtml)
            if match:
                link = match.group(1)
                common.log('link: ' + link)

                embedlink = link.split('?')[0].split('/')
                embedlink[-1] = 'getSources?id=' + embedlink[-1]
                embedlink = '/'.join(embedlink)
                common.log('embedlink: ' + embedlink)

                jsondata = requests.get(embedlink, headers={"X-Requested-With": "XMLHttpRequest"}).json()
                common.log('jsondata: ' + str(jsondata))

                encrypted_video_link = jsondata.get('sources', [])
                common.log('encrypted_video_link: ' + str(encrypted_video_link))

                try:
                    keys = requests.get("https://justarion.github.io/keys/e1-player/src/data/keys.json").json()
                    common.log('keys: ' + str(keys))

                    host = re.search(r'https?://([^/.]+)', link).group(1)
                    common.log('host: ' + host)
                    key = keys.get(host, None)['movie']['key']
                    common.log('key: ' + str(key))

                    OpenSSL_AES = openssl_aes.AESCipher()
                    sources = OpenSSL_AES.decrypt(encrypted_video_link, key)
                    sources = json.loads(sources)

                    common.log('sources: ' + str(sources))
                    videourl = sources[0]["file"]

                    if simple_info.get("title"):
                        release_name = f'{common.cleantext(item["title"])} ({item["year"]})'
                    else:
                        release_name = f'{common.cleantext(item["title"])}: {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'

                    if "tracks" in jsondata:
                        for track in jsondata["tracks"]:
                            if ('hun' in track["label"].lower() or 'rom' in track["label"].lower() or 'eng' in track["label"].lower()) and track["label"].lower() not in ('bengali'):
                                common.log(track["label"].lower())
                                if track["file"] not in self.subs:
                                    self.subs.append(track["file"])

                    referer = re.search(r'(https?://[^/]+/)', link).group(1)
                    common.log('referer: ' + referer)
                    debrid_provider = f'{servername} - {referer.split("//")[-1].split("/")[0]}'
                    common.log('debrid_provider: ' + debrid_provider)

                    if servername == 'UpCloud':
                        videourl = videourl + '|referer=' + referer
                        referer = None
                    common.log('videourl:' + videourl)

                    source_ = {
                        "referer": referer,
                        "scraper": "sflix",
                        "release_title": release_name,
                        # "info": "",
                        # "size": 0,
                        "quality": "1080p",
                        "url": videourl,
                        "debrid_provider": debrid_provider,
                        # "headers": "",
                        "filetype": "hls",
                        "subs": self.subs,
                    }
                    common.log('****** source_: ' + str(source_))
                    source.append(source_)
                except Exception as error:
                    common.log(f"Error processing source: {error}", "error")
                    continue

            # try:
            #     forbidden_chars = '"*\\/\'.|?:<>'
            #     file_name = ''.join([x if x not in forbidden_chars else '_' for x in release_name]) + '.txt'
            #     path = xbmcvfs.translatePath("special://subtitles")
            #     if path is None or path == '':
            #         path = xbmcvfs.translatePath("special://temp")
            #     file_name = os.path.join(path, file_name)

            #     if os.path.isfile(file_name):
            #         os.remove(file_name)

            #     with open(file_name, 'w') as filehandle:
            #         for sub in self.subs:
            #             filehandle.writelines(f"{sub}\n")
            # except Exception as error:
            #     common.log(error)
        return source

    def episode(self, simple_info, info):
        self.start_time = time.time()
        sources = []

        query = clean_title(simple_info["show_title"]).replace(' ', '-')
        try:
            results = self._make_query(query, simple_info['year'], 'TV')
            for item in results:
                source = self._process_item(item, simple_info)
                for ss in source:
                    sources.append(ss)
            return self._return_results("episode", sources)
        except PreemptiveCancellation:
            return self._return_results("episode", sources, preemptive=True)

    def movie(self, title, year, imdb, simple_info, info):
        self.start_time = time.time()
        sources = []

        year = simple_info["year"]
        query = clean_title(simple_info["title"]).replace(' ', '-')
        try:
            results = self._make_query(query, year, 'Movie')
            for item in results:
                source = self._process_item(item, simple_info)
                for src in source:
                    if src is not None:
                        sources.append(src)
            return self._return_results("movie", sources)
        except PreemptiveCancellation:
            return self._return_results("movie", sources, preemptive=True)

    # @staticmethod
    def get_subs(self):
        return self.subs

    @staticmethod
    def get_listitem(return_data):
        list_item = xbmcgui.ListItem(path=return_data["url"], offscreen=True)
        list_item.setContentLookup(False)
        list_item.setProperty("isFolder", "false")
        list_item.setProperty("isPlayable", "true")

        referer = return_data.get('referer')
        if referer:
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.stream_headers', f'Referer={referer}')

        # subs = []
        # forbidden_chars = '"*\\/\'.|?:<>'
        # file_name = ''.join([x if x not in forbidden_chars else '_' for x in return_data.get('release_title')]) + '.txt'
        # path = xbmcvfs.translatePath("special://subtitles")
        # if path is None or path == '':
        #     path = xbmcvfs.translatePath("special://temp")
        # file_name = os.path.join(path, file_name)
        # if os.path.isfile(file_name):
        #     with open(file_name, 'r') as filehandle:
        #         subs = [sub.rstrip() for sub in filehandle.readlines()]

        subs = return_data.get('subs', [])
        list_item.setSubtitles(subs)

        return list_item
