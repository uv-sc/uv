# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core import Core
import re
import requests
from resources.lib.common.source_utils import get_info


class Core2(Core):
    def __init__(self):
        super().__init__()
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        self.url_skip_re = None
        self.title_skip_re = None

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        headers = {'User-Agent': self.user_agent}
        if type == 'TV':
            item_url = f"{self.base_url}series/{imdb_id}:{simple_info['season_number']}:{simple_info['episode_number']}.json"
        else:
            item_url = f"{self.base_url}movie/{imdb_id}.json"
        self.log(f"Making query to: {item_url}")
        try:
            response = requests.get(item_url, headers=headers, timeout=30)
            return response.json() if response.status_code == 200 else []
        except Exception as e:
            self.log(f'Querry error: {e}')
            return []

    def _process_item(self, item, simple_info):
        sources = []
        streams = item.get('streams', []) if isinstance(item, dict) else item
        self.log(f"{len(streams)} streams found")
        self.log(streams)

        if not streams:
            return []

        for stream in streams:
            video_url = stream.get('url')
            self.log(video_url)

            if self.check_url_processed(video_url):
                continue
            
            if not video_url or (self.url_skip_re and re.search(self.url_skip_re, video_url, re.IGNORECASE)):
                self.log('  > Skipping source due to url skip regex match or missing url')
                continue

            if 'video-downloads.googleusercontent' in video_url:
                self.log('  > Skipping source due to googleusercontent link')
                continue

            raw_title = stream.get('title', '')
            if self.title_skip_re and re.search(self.title_skip_re, raw_title, re.IGNORECASE):
                self.log('  > Skipping source due to title skip regex match')
                continue
            
            video_url = video_url.replace('pixeldrain.dev/u/', 'pixeldrain.dev/api/file/')

            name = stream.get('name', 'Unknown')
            if name == 'MultiStream':
                name = video_url.split('/')[2]
            raw_title = self.flag_to_code(raw_title)

            release_name = raw_title.split("\n")[0].strip()

            provider = stream.get('behaviorHints', {}).get('bingeGroup', name)
            provider = provider.lower().split('-')
            if len(provider) > 2:
                provider = provider[2].strip()
            else:
                provider = provider[0].strip()

            size_bytes = stream.get('behaviorHints', {}).get('videoSize')
            if not size_bytes:
                match = re.search(r'(\d+\.\d+)\s*(GB|MB|KB)', raw_title)
                if match:
                    try:
                        size_bytes = float(match.group(1)) * (1024 ** 2 if match.group(2).upper() == 'MB' else 1024 ** 3 if match.group(2).upper() == 'GB' else 1024)
                    except ValueError as e:
                        self.log(f"Error converting size to bytes: {e}")
                        size_bytes = None
            size = size_bytes / (1024 ** 2) if size_bytes else None

            url_type = self.check_url(video_url)
            if not url_type:
                continue

            self.log("      ---------")
            self.log(f"Found source - Title: {release_name}, Provider: {provider}, Size: {size} MB")
            self.log(f"url_type: {url_type} - {video_url}")
            self.log("      ---------")

            source = {
                "release_title": release_name,
                "url": f"{video_url}|User-Agent={self.user_agent}",
                "debrid_provider": provider,
                "filetype": url_type,
                "info": get_info(release_name),
                "subs": []
            }
            if size:
                source["size"] = size
            if 'vixsrc' in provider:
                if 'resolution' in stream:
                    source["quality"] = stream['resolution']
                else:
                    source["quality"] = "1080p"
                source["filetype"] = "hls"
            sources.append(source)
        self.log('url_list: ' + str(self.url_list))            
        return sources
