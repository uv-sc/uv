# -*- coding: utf-8 -*-
from providerModules.uvScrapers import common
from providerModules.uvScrapers.core import Core
import re
import requests
from urllib.parse import urlparse
import base64
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad
from resources.lib.modules.exceptions import PreemptiveCancellation


class sources(Core):
    def __init__(self):
        super().__init__()
        self.base_url = "https://111movies.com/"
        self.provider = "111movies"
        default_domain = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(self.base_url))
        self.headers = {
            "Referer": default_domain,
            "User-Agent": self.user_agent,
            "Content-Type": "text/javascript",
            "X-Csrf-Token": "WP6BXZEsOAvSP0tk4AhxIWllVsuBx0Iy"
        }

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        season_number = simple_info.get("season_number", 1)
        episode_number = simple_info.get("episode_number", 1)
        query_url = f"{self.base_url}tv/{tvdb_id}/{season_number}/{episode_number}" if type == "TV" else f"{self.base_url}movie/{imdb_id}"
        self.log(f"Query URL: {query_url}")      
        response = requests.get(query_url, headers=self.headers, timeout=60)
        if response.status_code != 200:
            return []
        return [response.text]

    def _process_item(self, item, simple_info):
        response = item[0]
        if simple_info.get("title"):
            release_name = f'{simple_info["title"]} ({simple_info["year"]})'
        else:
            release_name = f'{simple_info["show_title"]} ({simple_info["year"]}): {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'

        # Utility Functions
        ''' Encodes input using Base64 with custom character mapping. '''
        def custom_encode(input):
            src = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
            dst = "c86mtuVv2EUlDgX-1YSpoiTq9WJadfzNe_Rs53kMrKHQZnxL0wGCFBhb7AP4yIOj"
            trans = str.maketrans(src, dst)
            b64 = base64.b64encode(input.encode()).decode().replace('+', '-').replace('/', '_').replace('=', '')
            return b64.translate(trans)

        # Extract raw data
        match = re.search(r'{\"data\":\"(.*?)\"', response)
        if not match:
            self.log("No data found!")
            return []
        raw_data = match.group(1)

        # AES encryption setup
        # key_hex = ""
        # iv_hex = ""
        # aes_key = bytes.fromhex(key_hex)
        # aes_iv = bytes.fromhex(iv_hex)
        aes_key = bytes([138, 238, 17, 197, 68, 75, 124, 44, 53, 79, 11, 131, 216, 176, 124, 80, 161, 126, 163, 21, 238, 68, 192, 209, 135, 253, 84, 163, 18, 158, 148, 102])
        aes_iv = bytes([181, 63, 33, 220, 121, 92, 190, 223, 94, 49, 56, 160, 53, 233, 201, 230])

        cipher = AES.new(aes_key, AES.MODE_CBC, aes_iv)
        padded_data = pad(raw_data.encode(), AES.block_size)
        aes_encrypted = cipher.encrypt(padded_data).hex()

        # XOR operation
        # xor_key = bytes.fromhex("")
        xor_key = bytes([215, 136, 144, 55, 198])
        xor_result = ''.join(chr(ord(char) ^ xor_key[i % len(xor_key)]) for i, char in enumerate(aes_encrypted))

        # Custom encoded string
        encoded_final = custom_encode(xor_result)

        # Make final request
        static_path = "h/APA91Pu8JKhvEMftnB2QqFE9aSTlLqQF4iF0DRuk7YXkLqvJaUmlRlblS_1ZK6t2VIbx68GVQ5AVkepTGy82DLIz_uAyGx3Z421GLf2TIhbySFvE1bOInrzHRKLtjkPTpliKjWPhvPIzDjFmHp4zwMvRvqLhstjw4CVCy8jn-BuTxk1SRkl8s1r/ef860363-4e1b-5482-8d76-ec6fdebe974b/e993fc0bc499fdfb502f96b85963f9f0bbc698dd/wiv/1000044292358307/1bda1d30afdf5f775dcddb0a888bf9898b90ad4d3e1089396585236913b00773/ar"

        api_servers = f"https://111movies.com/{static_path}/{encoded_final}/sr"
        try:
            response = requests.get(api_servers, headers=self.headers)
            response = response.json()
        except Exception as e:
            self.log(f"Error fetching API servers: {e}")
            return []
        # server = random.choice(response)['data']
        provider = ''
        for rsp in response:
            server = rsp['data']
            provider = rsp["name"] + ' - ' + rsp["description"]
            api_stream = f"https://111movies.com/{static_path}/{server}"
            try:
                response = requests.get(api_stream, headers=self.headers).json()
                break
            except Exception as e:
                self.log(f"Error fetching API stream: {e} - {provider}")

        # try:
        #     dialog = xbmcgui.Dialog()
        #     idx = dialog.select("111MOVIES: Select a server", [s['name'] for s in response])
        #     self.log('Server selected: ' + str(idx))
        # except Exception as e:
        #     self.log(f"Error selecting server: {e}", "error")
        #     return []

        subs = []
        if "tracks" in response:
            self.subs = common.get_subs(response["tracks"], self.subs)
            subs = common.fix_subtitles(self.subs)

        # Extract video URL
        video_url = response['url']

        source = []
        try:
            source_ = {
                "referer": "https://111movies.com/",
                "release_title": release_name,
                "quality": "1080p",
                "url": video_url,
                "debrid_provider": provider,
                "filetype": "hls",
                "subs": subs,
            }
            source.append(source_)
        except Exception as error:
            self.log(f"Error processing source: {error}")
        return source
