# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core import Core
import re
import requests
import json


class sources(Core):
    def __init__(self):
        super().__init__()
        self.provider = "vixsrc"
        self.base_url = "https://vixsrc.to/"
        self.headers = {
            "Referer": self.base_url,
            "User-Agent": self.user_agent,
        }


    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        self.log(f"Making query for {type} with ID: {tvdb_id if type == 'TV' else imdb_id}")
        season_number = simple_info.get("season_number", 1)
        episode_number = simple_info.get("episode_number", 1)
        query_url = f"{self.base_url}tv/{tvdb_id}/{season_number}/{episode_number}" if type == "TV" else f"{self.base_url}movie/{tvdb_id}"
        self.log(f"Query URL: {query_url}")      
        response = requests.get(query_url, headers=self.headers, timeout=60)
        if response.status_code != 200:
            return []
        return [response.text]

    def _process_item(self, item, simple_info):
        if not item:
            return []
        response = item[0]

        if simple_info.get("title"):
            release_name = f'{simple_info["title"]} ({simple_info["year"]})'
        else:
            release_name = f'{simple_info["show_title"]} ({simple_info["year"]}): {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'
        self.log(f"Processing item: {release_name}")


        source = []
        match = re.search(r"window.masterPlaylist =\s+({.+?})\s", response, flags=re.DOTALL | re.IGNORECASE)
        if match:
            data = match.group(1)
            data = data.replace("params", "'params'").replace("url", "'url'")
            data = data.replace("\r", "").replace("\n", "").replace(" ", "")
            data = data.replace(",}", '}')
            data = data.replace("'", '"')
            self.log(data)
            try:
                jdata = json.loads(data)
            except Exception as e:
                self.log(f"JSON decoding error: {e}")
                return []
            self.log("Extracted JSON data from page: " + str(jdata))

            url = jdata.get("url")
            token = jdata.get("params", {}).get("token")
            expires = jdata.get("params", {}).get("expires")

            video_url = f'{url}&token={token}&expires={expires}&h=1&lang=en' if '?' in url else f'{url}?token={token}&expires={expires}&h=1&lang=en'

            if self.check_url_processed(video_url):
                return []

            self.log("Constructed video URL: " + video_url)

            try:
                source_ = {
                    "referer": self.base_url,
                    "release_title": release_name,
                    "quality": "1080p",
                    "url": video_url,
                    "debrid_provider": self.provider,
                    "filetype": "hls",
                }
                source.append(source_)
            except Exception as error:
                self.log(f"Error processing source: {error}")
        return source
