# -*- coding: utf-8 -*-
from providerModules.uvScrapers import common
import re
import requests
import time
import xbmcgui
from urllib.parse import unquote_plus
from resources.lib.modules.exceptions import PreemptiveCancellation


url_list = []


class Core():
    def __init__(self):
        self.provider = ""
        self.base_url = ""
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        self.language = ["en"]
        self.start_time = 0
        self.subs = []
        self.url_list = url_list

    def log(self, message, level='debug'):
        common.log(f'{self.provider.upper()} >>> {message}', level=level)

    def check_url_processed(self, url):
        if '?' in url and '.php?' not in url:
            url = url.split('?')[0]
        url = url.strip().lower().replace('.m3u8', '')
        url = unquote_plus(url)
        if url in self.url_list:
            self.log('  > Skipping source as URL already processed')
            return True
        else:
            self.url_list.append(url)
            return False

    def check_url(self, url, timeout=10):
        try:
            response = requests.head(url, headers={'User-Agent': self.user_agent}, timeout=timeout, allow_redirects=True)
            if response.status_code >= 400:
                self.log(f"URL returned status code {response.status_code}: {url}")
                return False
            content_type = response.headers.get('Content-Type', '').lower()
            hls_content_types = [
                'application/vnd.apple.mpegurl',
                'application/x-mpegurl',
                'audio/mpegurl'
            ]
            is_hls = any(ct in content_type for ct in hls_content_types)
            if is_hls:
                return "hls"
            else:
                if "text/html" in content_type and ".m3u8" in url:
                    return "hls"
                elif "video" in content_type or "application/octet-stream" in content_type:
                    return "direct"
                elif "application/x-zip" in content_type:
                    return False
                else:
                    self.log(f"Content-Type is: {content_type} for URL: {url}")
                    return "direct"
        except requests.RequestException as e:
            self.log(f"Error checking Content-Type: {e}")
            return False

    def flag_to_code(self, text):
        def replace_flag(match):
            letters = ''.join(chr(cp - 0x1F1E6 + ord('A')) for cp in [ord(c) for c in match.group(0)])
            return ' ' + letters + ' '

        pattern = r'[\U0001F1E6-\U0001F1FF]{2}'
        result = re.sub(pattern, replace_flag, text)
        result = re.sub(r' +', ' ', result)
        return result.strip()

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        return []

    def _process_item(self, item, simple_info):
        return []

    def episode(self, simple_info, info):
        self.start_time = time.time()

        imdb_id = info["info"].get("tvshow.imdb_id") or info["info"].get("imdb_id")
        tvdb_id = info["info"].get("tvshow.tmdb_id")
        query = simple_info["show_title"]

        sources = []
        try:
            item = self._make_query(query, imdb_id, tvdb_id, simple_info, "TV")
            source = self._process_item(item, simple_info)
            for src in source:
                if src is not None:
                    sources.append(src)
            return self._return_results("episode", sources)
        except PreemptiveCancellation:
            return self._return_results("episode", sources, preemptive=True)

    def movie(self, title, year, imdb, simple_info, info):
        self.start_time = time.time()

        imdb_id = imdb
        tvdb_id = info.get("info").get("tmdb_id")
        query = simple_info["title"]

        sources = []
        try:
            item = self._make_query(query, imdb_id, tvdb_id, simple_info, "Movie")
            source = self._process_item(item, simple_info)
            for src in source:
                if src is not None:
                    sources.append(src)
            return self._return_results("movie", sources)
        except PreemptiveCancellation:
            return self._return_results("movie", sources, preemptive=True)

    def _return_results(self, source_type, sources, preemptive=False):
        if preemptive:
            self.log(f"uvScrapers.{source_type}: cancellation requested", "info",)
        elif preemptive is None:
            self.log(f"uvScrapers.{source_type}: not authorized", "info",)

        self.log(f"uvScrapers.{source_type}: Found {len(sources)} sources", "info")
        self.log(f"uvScrapers.{source_type}: Took {int((time.time() - self.start_time) * 1000)} ms", "info",)
        return sources

    @staticmethod
    def get_listitem(return_data):
        list_item = xbmcgui.ListItem(path=return_data["url"], offscreen=True)
        list_item.setContentLookup(False)
        list_item.setProperty("isFolder", "false")
        list_item.setProperty("isPlayable", "true")

        if return_data.get('filetype') == 'hls':
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            referer = return_data.get('referer')
            if referer:
                list_item.setProperty('inputstream.adaptive.stream_headers', f'Referer={referer}')

        subs = return_data.get('subs', [])
        if subs:
            list_item.setSubtitles(subs)
        return list_item
