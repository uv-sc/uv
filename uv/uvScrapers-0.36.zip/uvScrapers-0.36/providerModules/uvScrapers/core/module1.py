# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core import Core
from providerModules.uvScrapers import common
import re
import requests
from urllib.parse import urlparse, quote_plus


class Core1(Core):
    def __init__(self):
        super().__init__()
        self.decode_url = "https://script.google.com/macros/s/AKfycbxHbYHbrGMXYD2-bC-C43D3njIbU-wGiYQuJL61H4vyy6YVXkybMNNEPJNPPuZrD1gRVA/exec"
        self.key_url = "https://raw.githubusercontent.com/yogesh-hacker/MegacloudKeys/refs/heads/main/keys.json"
        self.client_key = ""

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):

        year = str(simple_info["year"])
        data = f"keyword={quote_plus(query)}"
        headers = {
            "Referer": self.base_url,
            "User-Agent": self.user_agent,
            "Origin": self.base_url,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
        }
        query_url = f"{self.base_url}ajax/search"
        self.log(f"Query URL: {query_url}")
        search_results = requests.post(query_url, headers=headers, data=data).text
        results = re.split(r'</div>\s*</a>', search_results)

        exact_matches = []
        matches = []
        for result in results:
            match = re.search(r'<a\s+href="/([^"]+)"', result, flags=re.DOTALL | re.IGNORECASE)
            if match:
                video_url = self.base_url + match.group(1)
            else:
                continue

            match = re.search(r'<span>(TV|Movie)</span>', result, flags=re.DOTALL | re.IGNORECASE)
            qtype = match.group(1) if match else ''
            self.log('qtype: ' + qtype + ' type: ' + type)

            if qtype.lower() != type.lower():
                continue

            qyear = ''
            if type == 'Movie':
                match = re.search(r'<div class="film-infor">\s*<span>(\d+)</span>', result, flags=re.DOTALL | re.IGNORECASE)
                if match:
                    qyear = match.group(1)
                    if year != qyear:
                        continue

            match = re.search('title="([^"]+)"', result, flags=re.DOTALL | re.IGNORECASE)
            title = match.group(1) if match else ''

            if query.lower() == title.lower():
                exact_matches.append({'title': title, 'video_url': video_url, 'year': qyear if type == 'Movie' else year})
            else:
                matches.append({'title': title, 'video_url': video_url, 'year': qyear if type == 'Movie' else year})

        self.log(matches)
        self.log(exact_matches)

        results = []
        if len(exact_matches) == 1:
            results.append(exact_matches[0])
        elif len(exact_matches) > 1:
            for video in exact_matches:
                video_page = requests.get(video['video_url']).text
                match = re.search(r'Released:\D+(\d{4})\D', video_page)
                if match:
                    released = match.group(1)
                    if released != year:
                        continue
                results.append(video)

        if len(results) == 0:
            results = matches
        return results

    def _process_item(self, item, simple_info):
        self.log('Processing item: ' + str(item))
        item = item[0]
        season = simple_info.get('season_number')
        episode = simple_info.get('episode_number')
        self.log('season: ' + str(season) + ' episode: ' + str(episode))
        url = item['video_url']
        id = url.split('-')[-1]

        if season:
            seasonsurl = self.base_url + 'ajax/season/list/' + id
            self.log('seasonsurl: ' + seasonsurl)
            seasonshtml = requests.get(seasonsurl).text
            match = re.compile(rf'href="#ss-episodes-(\d+)">Season\s*{season}', re.DOTALL | re.IGNORECASE).findall(seasonshtml)
            if not match:
                return
            seasonid = match[0]
            self.log('seasonid: ' + seasonid)
            season = f'S{season}'

            episodeurl = self.base_url + 'ajax/season/episodes/' + seasonid
            episodeurl = self.base_url + 'ajax/season/episodes/' + seasonid
            self.log('episodeurl: ' + episodeurl)
            episodehtml = requests.get(episodeurl).text
            match = re.compile(rf'data-id="(\d+)"[^_]+?alt="Episode\s*0*{episode}"', re.DOTALL | re.IGNORECASE).findall(episodehtml) or re.compile(rf'data-id="(\d+)"[^>]+?title="Eps\s*0*{episode}', re.DOTALL | re.IGNORECASE).findall(episodehtml)

            if not match:
                return
            id = match[0]
            self.log('server id: ' + str(match[0]))

        serverurl = self.base_url + 'ajax/episode/list/' + id if '/movie/' in url else self.base_url + 'ajax/episode/servers/' + id
        self.log('serverurl: ' + serverurl)
        serverhtml = requests.get(serverurl).text

        match = re.compile(r'(?:data-linkid|data-id)="(\d+)".+?<span>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(serverhtml)
        self.log('match: ' + str(match))
        if not match:
            return

        source = []
        self.subs = []

        response = requests.get(self.key_url).json()
        if not response:
            self.log("Failed to retrieve keys from the key URL", "error")
            return []
        key = response['vidstr']

        for serverid, servername in match:
            self.log('\n\nservername: ' + servername + ' serverid: ' + serverid + '\n')
            if servername not in ('UpCloud', 'MegaCloud', 'Vidcloud'):  # 'AKCloud'
                self.log(f"Skipping server: {servername}", "info")
                continue

            provider_url = self.base_url + 'ajax/episode/sources/' + serverid
            self.log('provider_url: ' + provider_url)

            base_url = requests.get(provider_url).json()['link']
            self.log('base_url: ' + base_url)

            parsed_url = urlparse(base_url)
            default_domain = f"{parsed_url.scheme}://{parsed_url.netloc}/"
            headers = {
                "Accept": "*/*",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": default_domain,
                "User-Agent": self.user_agent
            }
            response = requests.get(base_url, headers=headers).text

            match = re.search(r'player" data-id="(\w+)"', response)
            if match:
                file_id = match.group(1)
            else:
                self.log(f"Skipping server {servername} due to missing file_id", "info")
                self.log('Response: ' + response)
                continue

            match = re.search(r'\b[a-zA-Z0-9]{48}\b', response) or re.search(r'\b([a-zA-Z0-9]{16})\b.*?\b([a-zA-Z0-9]{16})\b.*?\b([a-zA-Z0-9]{16})\b', response)
            if not match:
                self.log(f"Skipping server {servername} due to missing nonce", "info")
                continue
            nonce = ''.join(match.groups()) if match and match.lastindex == 3 else match.group() if match else None
            if not nonce:
                self.log(f"Skipping server {servername} due to missing nonce", "info")
                continue
            embed_link = f'{default_domain}embed-1/v3/e-1/getSources?id={file_id}&_k={nonce}'
            self.log('embed_link: ' + embed_link)

            embed_response = requests.get(embed_link, headers=headers).json()
            self.log('embed_response: ' + str(embed_response))
            encrypted = embed_response.get('encrypted')
            self.log('encrypted: ' + str(encrypted))

            # Extract video URL
            if encrypted:
                # Get required values to decode
                encrypted_data = quote_plus(embed_response['sources'])
                nonce_encoded = quote_plus(nonce)
                key_encoded = quote_plus(key)

                # Decoding is handled on the server side to avoid PRNG-related issues in Python
                # Original server-side implementation reference: https://github.com/yogesh-hacker/yogesh-hacker/blob/main/js/videostr.js
                decode_url = f"{self.decode_url}?encrypted_data={encrypted_data}&nonce={nonce_encoded}&secret={key_encoded}"
                self.log('decode_url: ' + decode_url)
                response = requests.get(decode_url, allow_redirects=True).text
                match = re.search(r'\"file\":\"(.*?)\"', response)
                video_url = match.group(1) if match else None
            else:
                video_url = embed_response['sources'][0]['file']

            if video_url:
                try:
                    if simple_info.get("title"):
                        release_name = f'{item["title"]} ({item.get("year", "")})'
                    else:
                        release_name = f'{item["title"]} ({item.get("year", "")}): {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title", "")}'
                    release_name = common.cleantext(release_name)

                    subs = []
                    if "tracks" in embed_response:
                        self.subs = common.get_subs(embed_response["tracks"], self.subs)
                        subs = common.fix_subtitles(self.subs)

                    referer = default_domain
                    filetype = 'hls'
                    debrid_provider = f'{servername} - {parsed_url.netloc}'

                    if servername == 'UpCloud':
                        video_url = video_url + '|referer=' + referer
                        referer = None
                        filetype = 'direct'

                    source_ = {
                        "referer": referer,
                        "scraper": self.provider,
                        "release_title": release_name,
                        "quality": "1080p",
                        "url": video_url,
                        "debrid_provider": debrid_provider,
                        "filetype": filetype,
                        "subs": subs,
                    }
                    self.log('*** source_: ' + str(source_))
                    source.append(source_)
                except Exception as error:
                    self.log(f"Error processing source: {error}")
                    continue
        self.log('url_list: ' + str(self.url_list))
        return source
