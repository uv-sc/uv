# -*- coding: utf-8 -*-
from providerModules.uvScrapers import common
from providerModules.uvScrapers.core import Core
import re
import requests
from urllib.parse import urlparse
import base64
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad


class sources(Core):
    def __init__(self):
        super().__init__()
        self.base_url = "https://111movies.com/"
        self.provider = "111movies"
        default_domain = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(self.base_url))
        self.headers = {
            "Referer": default_domain,
            "User-Agent": self.user_agent,
            "Content-Type": "image/gif",
            "X-Requested-With": "XMLHttpRequest"
        }

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        season_number = simple_info.get("season_number", 1)
        episode_number = simple_info.get("episode_number", 1)
        query_url = f"{self.base_url}tv/{tvdb_id}/{season_number}/{episode_number}" if type == "TV" else f"{self.base_url}movie/{imdb_id}"
        self.log(f"Query URL: {query_url}")
        response = requests.get(query_url, headers=self.headers, timeout=60)
        if response.status_code != 200:
            return []
        return [response.text]

    def _process_item(self, item, simple_info):
        response = item[0]
        if simple_info.get("title"):
            release_name = f'{simple_info["title"]} ({simple_info["year"]})'
        else:
            release_name = f'{simple_info["show_title"]} ({simple_info["year"]}): {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'

        # Utility Functions
        ''' Encodes input using Base64 with custom character mapping. '''
        def custom_encode(input):
            src = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
            dst = "Ms8P1hR9n4qUdVfzgNwkIYBWTJbleyESG623C7OoKQp-DA0cjHX_mZuFivxra5Lt"

            trans = str.maketrans(src, dst)
            b64 = base64.b64encode(input.encode()).decode().replace('+', '-').replace('/', '_').replace('=', '')
            return b64.translate(trans)

        # Extract raw data
        match = re.search(r'{\"data\":\"(.*?)\"', response)
        if not match:
            self.log("No data found!")
            return []
        raw_data = match.group(1)
        self.log(f"Raw data extracted: {raw_data}")

        # AES encryption setup
        # key_hex = ""
        # iv_hex = ""
        # aes_key = bytes.fromhex(key_hex)
        # aes_iv = bytes.fromhex(iv_hex)
        aes_key = bytes([30, 205, 221, 166, 245, 211, 17, 215, 25, 112, 53, 178, 204, 220, 113, 119, 70, 159, 203, 220, 234, 187, 144, 97, 196, 89, 101, 49, 155, 194, 26, 228])
        aes_iv = bytes([65, 172, 88, 238, 7, 208, 1, 66, 59, 83, 149, 148, 89, 151, 60, 247])

        cipher = AES.new(aes_key, AES.MODE_CBC, aes_iv)
        padded_data = pad(raw_data.encode(), AES.block_size)
        aes_encrypted = cipher.encrypt(padded_data).hex()

        # XOR operation
        # xor_key = bytes.fromhex("")
        xor_key = bytes([241, 79, 29, 187, 103, 163, 87])
        xor_result = ''.join(chr(ord(char) ^ xor_key[i % len(xor_key)]) for i, char in enumerate(aes_encrypted))

        # Custom encoded string
        encoded_final = custom_encode(xor_result)
        self.log(f"Encoded final string: {encoded_final}")

        # Make final request
        static_path = "83430c172a325878deb69e1b2fa7e181c2a9ba8c/1000060586693258/rok/64c494bc/APA91vW7CQJ31D2QQ8VDZUpUI_zVwZ83CqikuxttWjExUTfZ_0g7Dlh0vXAucB5uurMpb8Da7lInYp2-SJYL-2FbVyV8Nl6MVtfHSli8-a0fmWg4ugQG7nJUATHwIcmrY3hOHfBXomhis43rTXlY7_bpr48Ye_X930EZ-bXA5fvUZby8TRWcfZY/kovnifuc/z/3c9419f41db48b15a08b573e289bbc892ca8aa11625fb2ac753bb59b150d34f9"
        api_servers = f"https://111movies.com/{static_path}/{encoded_final}/sr"

        self.log(f"API Servers URL: {api_servers}")
        try:
            response = requests.post(api_servers, headers=self.headers)
            response = response.json()
        except Exception as e:
            self.log(f"Error fetching API servers: {e}")
            return []
        # server = random.choice(response)['data']
        self.log(f"API Servers response: {response}")
        provider = ''
        for rsp in response:
            server = rsp['data']
            provider = rsp["name"] + ' - ' + rsp["description"]
            api_stream = f"https://111movies.com/{static_path}/{server}"
            try:
                response = requests.post(api_stream, headers=self.headers).json()
                break
            except Exception as e:
                self.log(f"Error fetching API stream: {e} - {provider}")

        # try:
        #     dialog = xbmcgui.Dialog()
        #     idx = dialog.select("111MOVIES: Select a server", [s['name'] for s in response])
        #     self.log('Server selected: ' + str(idx))
        # except Exception as e:
        #     self.log(f"Error selecting server: {e}", "error")
        #     return []

        subs = []
        if "tracks" in response:
            self.subs = common.get_subs(response["tracks"], self.subs)
            subs = common.fix_subtitles(self.subs)

        video_url = response['url']

        source = []
        try:
            source_ = {
                "referer": "https://111movies.com/",
                "release_title": release_name,
                "quality": "1080p",
                "url": video_url,
                "debrid_provider": provider,
                "filetype": "hls",
                "subs": subs,
            }
            source.append(source_)
        except Exception as error:
            self.log(f"Error processing source: {error}")
        return source
