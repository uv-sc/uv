# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core.module1 import Core1


class sources(Core1):
    def __init__(self):
        super().__init__()
        self.provider = "flixhq"
        self.base_url = "https://flixhq.to/"
