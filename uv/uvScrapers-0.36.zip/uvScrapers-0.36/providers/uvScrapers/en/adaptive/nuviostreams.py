# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core.module2 import Core2


class sources(Core2):
    def __init__(self):
        super().__init__()
        self.provider = "nuviostreams"
        self.base_url = "https://nuviostreams.hayd.uk/stream/"
        self.skip_re = 'https://pub-'
