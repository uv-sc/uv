# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core.module2 import Core2


class sources(Core2):
    def __init__(self):
        super().__init__()
        self.provider = "vega_vflix"
        self.base_url = "https://vega.vflix.life/stream/"
        self.title_skip_re = r'\s[345678]\d\dp\s'
