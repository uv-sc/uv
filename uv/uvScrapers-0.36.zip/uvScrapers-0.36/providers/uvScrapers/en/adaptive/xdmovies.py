# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core.module2 import Core2


class sources(Core2):
    def __init__(self):
        super().__init__()
        self.provider = "xdmovies"
        self.base_url = "https://xdmovies-stremio.hdmovielover.workers.dev/"
        self.tv_url = "{self.base_url}series?imdbid={imdb_id}&s={simple_info['season_number']}&e={simple_info['episode_number']}"
        self.movie_url = "{self.base_url}movie?imdbid={imdb_id}"
