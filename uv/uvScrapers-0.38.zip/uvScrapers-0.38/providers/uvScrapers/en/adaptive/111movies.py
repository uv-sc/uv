# -*- coding: utf-8 -*-
from providerModules.uvScrapers import common
from providerModules.uvScrapers.core import Core
import re
import requests
from urllib.parse import urlparse
import base64
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad


class sources(Core):
    def __init__(self):
        super().__init__()
        self.base_url = "https://111movies.net/"
        self.provider = "111movies"
        default_domain = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(self.base_url))
        self.headers = {
            "Referer": default_domain,
            "User-Agent": self.user_agent,
            "Content-Type": "application/gzip",
        }

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        season_number = simple_info.get("season_number", 1)
        episode_number = simple_info.get("episode_number", 1)
        query_url = f"{self.base_url}tv/{tvdb_id}/{season_number}/{episode_number}" if type == "TV" else f"{self.base_url}movie/{imdb_id}"
        self.log(f"Query URL: {query_url}")
        response = requests.get(query_url, headers=self.headers, timeout=60)
        if response.status_code != 200:
            return []
        return [response.text]

    def _process_item(self, item, simple_info):
        response = item[0]
        if simple_info.get("title"):
            release_name = f'{simple_info["title"]} ({simple_info["year"]})'
        else:
            release_name = f'{simple_info["show_title"]} ({simple_info["year"]}): {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'

        # Utility Functions
        ''' Encodes input using Base64 with custom character mapping. '''
        def custom_encode(input):
            src = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
            dst = "Ckbl5ym-WLAev9dTuhpgK8PHtSGa2EBDnjMZR_Y0Xx7co1qrfFNJOQ6iUs4zIVw3"
            trans = str.maketrans(src, dst)
            b64 = base64.b64encode(input.encode()).decode().replace('+', '-').replace('/', '_').replace('=', '')
            return b64.translate(trans)

        # Extract raw data
        match = re.search(r'{\"data\":\"(.*?)\"', response)
        if not match:
            self.log("No data found!")
            return []
        raw_data = match.group(1)
        self.log(f"Raw data extracted: {raw_data}")

        # AES encryption setup
        key_hex = "ecc34a66edea3dcd48c8733812365f5caf7d28865993ae5fdc4a08436736a998"
        iv_hex = "4b47db0a764158dff36db37d27fdfcea"
        aes_key = bytes.fromhex(key_hex)
        aes_iv = bytes.fromhex(iv_hex)
        # aes_key = bytes([163, 73, 201, 215, 80, 148, 72, 108, 211, 185, 124, 54, 101, 182, 163, 145, 230, 167, 100, 17, 243, 106, 71, 213, 207, 26, 50, 65, 94, 82, 126, 167])
        # aes_iv = bytes([104, 59, 177, 195, 206, 252, 205, 31, 88, 68, 67, 47, 14, 83, 41, 141])

        cipher = AES.new(aes_key, AES.MODE_CBC, aes_iv)
        padded_data = pad(raw_data.encode(), AES.block_size)
        aes_encrypted = cipher.encrypt(padded_data).hex()

        # XOR operation
        # xor_key = bytes.fromhex("")
        # xor_key = bytes([160, 186, 53])
        xor_key = bytes.fromhex("fafd3f")
        xor_result = ''.join(chr(ord(char) ^ xor_key[i % len(xor_key)]) for i, char in enumerate(aes_encrypted))

        # Custom encoded string
        encoded_final = custom_encode(xor_result)
        self.log(f"Encoded final string: {encoded_final}")

        # Make final request
        static_path = "APA91z6a9CYF3L6StzwNlIs5j2LKG0HDcvCgRGTeS9nNSWT_z-mUqshnN852FBiC-v6OgWXJhgDNpCJqsMjQHtnrkk-9OesJ9cTkKseogBTlaFObhfNNBTPT4VZ0TVqTLKH-9t5e_fkch2ehWDh25--V7sR874GNGLCqjrWRpCD0RoAb4EwquyU"
        api_servers = f"{self.base_url}{static_path}/{encoded_final}/sr"

        self.log(f"API Servers URL: {api_servers}")
        try:
            response = requests.get(api_servers, headers=self.headers)
            response = response.json()
        except Exception as e:
            self.log(f"Error fetching API servers: {e}")
            return []
        # server = random.choice(response)['data']
        self.log(f"API Servers response: {response}")
        provider = ''
        for rsp in response:
            server = rsp['data']
            provider = rsp["name"] + ' - ' + rsp["description"]
            api_stream = f"{self.base_url}{static_path}/{server}"
            try:
                response = requests.get(api_stream, headers=self.headers).json()
                break
            except Exception as e:
                self.log(f"Error fetching API stream: {e} - {provider}")

        # try:
        #     dialog = xbmcgui.Dialog()
        #     idx = dialog.select("111MOVIES: Select a server", [s['name'] for s in response])
        #     self.log('Server selected: ' + str(idx))
        # except Exception as e:
        #     self.log(f"Error selecting server: {e}", "error")
        #     return []

        subs = []
        if "tracks" in response:
            self.subs = common.get_subs(response["tracks"], self.subs)
            subs = common.fix_subtitles(self.subs)

        video_url = response['url']

        source = []
        try:
            source_ = {
                "referer": self.base_url,
                "release_title": release_name,
                "quality": "1080p",
                "url": video_url,
                "debrid_provider": provider,
                "filetype": "hls",
                "subs": subs,
            }
            source.append(source_)
        except Exception as error:
            self.log(f"Error processing source: {error}")
        return source
