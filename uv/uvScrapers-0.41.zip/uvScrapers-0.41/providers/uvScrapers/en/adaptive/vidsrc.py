# -*- coding: utf-8 -*-
# from providerModules.uvScrapers import common
from providerModules.uvScrapers.core import Core
import re
import requests
from urllib.parse import urlparse


class sources(Core):
    def __init__(self):
        super().__init__()
        self.base_url = "https://vsembed.ru/"
        self.provider = "vidsrc"
        default_domain = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(self.base_url))
        self.headers = {
            "Referer": default_domain,
            "User-Agent": self.user_agent,
        }

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        season_number = simple_info.get("season_number", 1)
        episode_number = simple_info.get("episode_number", 1)
        query_url = f"{self.base_url}embed/tv/{tvdb_id}/{season_number}-{episode_number}" if type == "TV" else f"{self.base_url}embed/movie/{imdb_id}/"
        self.log(f"Query URL: {query_url}")
        response = requests.get(query_url, headers=self.headers, timeout=60)
        if response.status_code != 200:
            return []
        match = re.search(r'<iframe id="player_iframe" src="([^"]+)"', response.text, flags=re.DOTALL | re.IGNORECASE)
        if not match:
            return []
        iframe_url = "https:" + match.group(1) if match.group(1).startswith("//") else match.group(1)
        self.log(f"Extracted iframe URL: {iframe_url}")
        response = requests.get(iframe_url, headers=self.headers, timeout=60)
        if response.status_code != 200:
            return []
        self.headers["Referer"] = iframe_url
        iframe_domain = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(iframe_url))
        self.log(f"Updated headers with Referer: {self.headers['Referer']}")
        match = re.search(r"id:\s*'player_iframe',\s*src:\s*'([^']*)'", response.text, flags=re.DOTALL | re.IGNORECASE)
        if not match:
            return []
        iframe_url = iframe_domain + match.group(1) if match.group(1).startswith("/") else match.group(1)
        self.log(f"Extracted iframe URL from fallback: {iframe_url}")
        response = requests.get(iframe_url, headers=self.headers, timeout=60)
        if response.status_code != 200:
            return []
        match = re.search(r'{id:"player_parent",\s*file:\s*"([^"]*)"', response.text, flags=re.DOTALL | re.IGNORECASE)
        if not match:
            self.log("No file found in response!")
            return []
        videos = match.group(1).split(" or ")
        for video in videos:
            if video.endswith(".m3u8"):
                self.log(f"Found m3u8 URL: {video}")

        match = re.search(r'var\s+test_doms\s*=\s*(\[[^\]]+\])', response.text, flags=re.DOTALL | re.IGNORECASE)
        if not match:
            return []
        domains = eval(match.group(1))
        self.log(f"Extracted test domains: {domains}")
        result = []
        for id_dom, domain in enumerate(domains):
            for id_vid, video in enumerate(videos):
                if f'{{v{id_dom}}}' in video:
                    video = domain + video.split('}')[1]
                    result.append(video)

        return result

    def _process_item(self, item, simple_info):
        self.log(item)
        video_url = item[0]
        if simple_info.get("title"):
            release_name = f'{simple_info["title"]} ({simple_info["year"]})'
        else:
            release_name = f'{simple_info["show_title"]} ({simple_info["year"]}): {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'

        source = []
        try:
            source_ = {
                "referer": self.headers["Referer"],
                "release_title": release_name,
                "quality": "1080p",
                "url": video_url,
                "debrid_provider": self.provider,
                "filetype": "hls",
                "subs": [],
            }
            source.append(source_)
        except Exception as error:
            self.log(f"Error processing source: {error}")
        return source
