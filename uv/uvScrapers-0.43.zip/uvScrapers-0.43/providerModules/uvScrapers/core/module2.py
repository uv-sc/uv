# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core import Core
from providerModules.uvScrapers import common
import re
import requests
from resources.lib.common.source_utils import get_info
from urllib.parse import unquote


class Core2(Core):
    def __init__(self):
        super().__init__()
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        self.tv_url = "{self.base_url}series/{imdb_id}:{season_number}:{episode_number}.json"
        self.movie_url = "{self.base_url}movie/{imdb_id}.json"
        self.url_skip_re = None
        self.title_skip_re = None

    def resolve_url(self, url):
        url = url.split('download?url=')[1]
        self.log(f"Resolving download link: {url}")
        response = requests.get(url, headers={'User-Agent': self.user_agent}, timeout=30)
        ret = {}
        if response.status_code == 200:
            match = re.search(r'href\s*=\s*"(https://gamerxyt.com[^"]+)"', response.text, re.IGNORECASE | re.DOTALL)
            if match:
                url = match.group(1)
                response = requests.get(url, headers={'User-Agent': self.user_agent}, timeout=30)
                if response.status_code == 200:
                    match = re.compile(r'<a\s+href="([^"]+)"[^/]+/i> Download \[(.+?)\]', re.IGNORECASE | re.DOTALL).findall(response.text)
                    for url, name in match:
                        self.log(f"Found download link: {name} - {url}")
                        if '10Gbps' in name:
                            continue
                        ret[name] = url
                else:
                    self.log("No download link found in the response for url: {url}")
        return ret

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        self.log(simple_info)
        self.log(f"Making query for {type} with IMDb ID: {imdb_id}")
        headers = {'User-Agent': self.user_agent}
        if type == 'TV':
            season_number = simple_info.get("season_number", "0")
            episode_number = simple_info.get("episode_number", "0")
            item_url = self.tv_url.format(self=self, imdb_id=imdb_id, season_number=season_number, episode_number=episode_number)
        else:
            item_url = self.movie_url.format(self=self, imdb_id=imdb_id)
        self.log(f"Making query to: {item_url}")
        try:
            response = requests.get(item_url, headers=headers, timeout=30)
            return response.json() if response.status_code == 200 else []
        except Exception as e:
            self.log(f'Querry error: {e}')
            return []

    def _process_item(self, item, simple_info):
        sources = []
        subs = []
        streams = item.get('streams', []) if isinstance(item, dict) else item
        self.log(f"{len(streams)} streams found")

        if not streams:
            return []

        for stream in streams:
            video_url = stream.get('url')

            if 'hls?url=' in video_url:
                video_url = unquote(video_url.split('hls?url=')[1])

            self.log(f"\n\n\nvideo_url: {video_url}")

            raw_title = stream.get('title', '') or stream.get('name', '')

            if self.title_skip_re and re.search(self.title_skip_re, raw_title, re.IGNORECASE):
                self.log('  > Skipping source due to title skip regex match')
                continue

            name = stream.get('name', 'Unknown')
            if name == 'MultiStream':
                name = video_url.split('/')[2]
            raw_title = self.flag_to_code(raw_title)

            release_name = raw_title.split("\n")[0].strip()
            self.log(f"Initial release name: {release_name}")

            if 'MEOWTV' in release_name.upper():
                if simple_info.get("title"):
                    release_name = f'{simple_info["title"]} ({simple_info["year"]})'
                else:
                    release_name = f'{simple_info["show_title"]} ({simple_info["year"]}): {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'
                provider = 'meowtv'
                self.subs = common.get_subs(stream.get('subtitles', []), self.subs)
                subs = common.fix_subtitles(self.subs)
            else:
                provider = stream.get('behaviorHints', {}).get('bingeGroup', name)
                # provider = provider.lower().split('-')
                # if len(provider) > 2:
                #     provider = provider[2].strip()
                # else:
                #     provider = provider[0].strip()

            items = {}
            if 'download?url=' in video_url:
                items = self.resolve_url(video_url)

            if not items:
                items[provider] = video_url

            for provider, video_url in items.items():

                if self.check_url_processed(video_url):
                    continue

                if not video_url or (self.url_skip_re and re.search(self.url_skip_re, video_url, re.IGNORECASE)):
                    self.log('  > Skipping source due to url skip regex match or missing url')
                    continue

                if 'video-downloads.googleusercontent' in video_url:
                    self.log('  > Skipping source due to googleusercontent link')
                    continue

                video_url = video_url.replace('pixeldrain.dev/u/', 'pixeldrain.dev/api/file/')

                size_bytes = stream.get('behaviorHints', {}).get('videoSize')
                if not size_bytes:
                    match = re.search(r'(\d+\.\d+)\s*(GB|MB|KB)', raw_title)
                    if match:
                        try:
                            size_bytes = float(match.group(1)) * (1024 ** 2 if match.group(2).upper() == 'MB' else 1024 ** 3 if match.group(2).upper() == 'GB' else 1024)
                        except ValueError as e:
                            self.log(f"Error converting size to bytes: {e}")
                            size_bytes = None
                size = size_bytes / (1024 ** 2) if size_bytes else None

                url_type = self.check_url(video_url)

                if not url_type:
                    continue

                self.log("      ---------")
                self.log(f"Found source - Title: {release_name}, Provider: {provider}, Size: {size} MB")
                self.log(f"url_type: {url_type} - {video_url}")
                self.log("      ---------")

                source = {
                    "release_title": release_name,
                    "info": get_info(release_name),
                    "url": f"{video_url}|User-Agent={self.user_agent}",
                    "debrid_provider": provider,
                    "filetype": url_type,
                    "subs": subs
                }
                if size:
                    source["size"] = size
                if 'vixsrc' in provider:
                    if 'resolution' in stream:
                        source["quality"] = stream['resolution']
                    else:
                        source["quality"] = "1080p"
                    source["filetype"] = "hls"
                if provider == 'meowtv':
                    source["quality"] = stream.get('description', '1080p').split(' ')[-1].strip()
                    # source["filetype"] = "hls"

                sources.append(source)
        return sources
