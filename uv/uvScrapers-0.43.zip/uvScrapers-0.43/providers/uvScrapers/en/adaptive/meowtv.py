# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core.module2 import Core2


class sources(Core2):
    def __init__(self):
        super().__init__()
        self.provider = "meowtv"
        self.base_url = "https://meowtv.vflix.shop/stream/"
        self.title_skip_re = r'meowtv\s+\[auto\]'
