# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core.module2 import Core2


class sources(Core2):
    def __init__(self):
        super().__init__()
        self.provider = "webstreamr"
        self.base_url = "https://87d6a6ef6b58-webstreamrmbg.baby-beamup.club/stream/"
