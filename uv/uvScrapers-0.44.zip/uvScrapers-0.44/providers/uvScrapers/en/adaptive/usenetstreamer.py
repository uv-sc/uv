# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core.module3 import Core3


class sources(Core3):
    def __init__(self):
        super().__init__()
        self.provider = "usenetstreamer"
        self.base_url = "http://192.168.0.99:7000/api/stream/"
