# -*- coding: utf-8 -*-
from providerModules.uvScrapers.core import Core
import re
import requests
from resources.lib.common.source_utils import get_info


class Core3(Core):
    def __init__(self):
        super().__init__()
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        self.tv_url = "{self.base_url}series/{imdb_id}:{season_number}:{episode_number}.json"
        self.movie_url = "{self.base_url}movie/{imdb_id}.json"
        self.url_skip_re = None
        self.title_skip_re = None

    def _make_query(self, query, imdb_id, tvdb_id, simple_info, type):
        self.log(simple_info)
        self.log(f"Making query for {type} with IMDb ID: {imdb_id}")
        headers = {'User-Agent': self.user_agent}
        if type == 'TV':
            season_number = simple_info.get("season_number", "0")
            episode_number = simple_info.get("episode_number", "0")
            item_url = self.tv_url.format(self=self, imdb_id=imdb_id, season_number=season_number, episode_number=episode_number)
        else:
            item_url = self.movie_url.format(self=self, imdb_id=imdb_id)
        self.log(f"Making query to: {item_url}")
        try:
            response = requests.get(item_url, headers=headers, timeout=30)
            return response.json() if response.status_code == 200 else []
        except Exception as e:
            self.log(f'Querry error: {e}')
            return []

    def _process_item(self, item, simple_info):
        sources = []
        streams = item.get('streams', []) if isinstance(item, dict) else item
        self.log(f"{len(streams)} streams found")

        if not streams:
            return []

        for stream in streams:
            video_url = stream.get('url')

            self.log(f"\n\n\nvideo_url: {video_url}")

            raw_title = stream.get('title', '') or stream.get('name', '')

            if self.title_skip_re and re.search(self.title_skip_re, raw_title, re.IGNORECASE):
                self.log('  > Skipping source due to title skip regex match')
                continue

            release_name = stream.get('behaviorHints', {}).get('filename', 'Unknown')
            self.log(f"Initial release name: {release_name}")

            provider = stream.get('meta', {}).get('indexer', '')
            provider += " - Health: " + stream.get('meta', {}).get('healthCheck', {}).get('status', '')
            cached = stream.get('meta', {}).get('cached', False)
            if cached:
                provider += ' [COLOR orange]cached[/COLOR]'


            items = {}

            if not items:
                items[provider] = video_url

            for provider, video_url in items.items():

                if not video_url or (self.url_skip_re and re.search(self.url_skip_re, video_url, re.IGNORECASE)):
                    self.log('  > Skipping source due to url skip regex match or missing url')
                    continue

                size_bytes = stream.get('behaviorHints', {}).get('videoSize')
                if not size_bytes:
                    match = re.search(r'(\d+\.\d+)\s*(GB|MB|KB)', raw_title)
                    if match:
                        try:
                            size_bytes = float(match.group(1)) * (1024 ** 2 if match.group(2).upper() == 'MB' else 1024 ** 3 if match.group(2).upper() == 'GB' else 1024)
                        except ValueError as e:
                            self.log(f"Error converting size to bytes: {e}")
                            size_bytes = None
                size = size_bytes / (1024 ** 2) if size_bytes else None

                self.log("      ---------")
                self.log(f"Found source - Title: {release_name}, Provider: {provider}, Size: {size} MB")
                self.log("      ---------")

                source = {
                    "release_title": release_name,
                    "info": get_info(release_name),
                    "url": f"{video_url}",
                    "debrid_provider": provider,
                    "filetype": "direct"
                }
                if size:
                    source["size"] = size

                sources.append(source)
        return sources
