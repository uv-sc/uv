# -*- coding: utf-8 -*-
from providerModules.uvScrapers import common
from providerModules.uvScrapers.core.module3 import Core3
from resources.lib.modules.globals import g


class sources(Core3):
    def __init__(self):
        super().__init__()
        self.provider = "usenetstreamer"
        self.base_url = common.get_setting("usenetstreamer.url")
        if not self.base_url or not self.base_url.endswith('/stream/'):
            notify_msg = f"UsenetStreamer URL is not set or not ending with '/stream/'. Please set it in the provider settings to use this provider."
            g.notification("UsenetStreamer", notify_msg)
        # "http://192.168.0.99:7000/api/stream/"
