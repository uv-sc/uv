# -*- coding: utf-8 -*-
import re
import requests
import time
# import html
import json
import unicodedata
# from urllib.parse import quote
import xbmcgui
import xbmcvfs
import os
# import base64

from resources.lib.common.source_utils import (clean_title,)
from resources.lib.modules.exceptions import PreemptiveCancellation
from providerModules.uvScrapers import common
# try:
#     from providerModules.uvScrapers.pyaes import openssl_aes
# except Exception as error:
#     common.log(error)


class sources:
    def __init__(self):
        self.base_hdrs = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
            'Accept-Encoding': 'gzip',
            'Accept-Language': 'en-US,en;q=0.8',
            'Connection': 'keep-alive'
        }

        self.language = ["en"]
        self.base_link = "https://sflix.to/"
        self.search_link = "search/"
        self.query_link = f"{self.base_link}{self.search_link}"
        self.start_time = 0
        self.subs = []

    def _return_results(self, source_type, sources, preemptive=False):
        if preemptive:
            common.log(f"uvScrapers.{source_type}.sflix: cancellation requested", "info",)
        elif preemptive is None:
            common.log(f"uvScrapers.{source_type}.sflix: not authorized", "info",)

        common.log(f"uvScrapers.{source_type}.sflix: {len(sources)}", "info")
        common.log(f"uvScrapers.{source_type}.sflix: took {int((time.time() - self.start_time) * 1000)} ms", "info",)
        return sources

    def _make_query(self, query, year, type):
        query = "".join([c for c in unicodedata.normalize("NFKD", query) if unicodedata.category(c) != "Mn"])

        queryurl = self.query_link + query
        queryurl = queryurl.replace('%', '')
        listhtml = requests.get(queryurl, timeout=30).text

        videos = listhtml.split('<div class="flw-item">')
        videos.pop(0)
        results = []

        for video in videos:
            match = re.search('<a  href="/([^"]+)"', video, flags=re.DOTALL | re.IGNORECASE)
            if match:
                videourl = self.base_link + match.group(1)
            else:
                continue

            match = re.search(r'<span class="fdi-item">(\d+)</span>', video, flags=re.DOTALL | re.IGNORECASE)
            qyear = match.group(1) if match else ''
            if qyear != year:
                continue

            match = re.search('<span class="fdi-item"><strong>([^<]+)</strong></span>', video, flags=re.DOTALL | re.IGNORECASE)
            qtype = match.group(1) if match else ''
            if qtype != type:
                continue

            match = re.search('title="([^"]+)"', video, flags=re.DOTALL | re.IGNORECASE)
            title = common.cleantext(match.group(1)) if match else ''
            results.append({'title': title, 'year': year, 'videourl': videourl})

            title = clean_title(title).replace(' ', '-')
            if title == query:
                break
        common.log(f"uvScrapers.sflix: MAKE QUERY END {int((time.time() - self.start_time) * 1000)} ms", "info",)
        return results

    def _process_item(self, item, simple_info):
        season = simple_info.get('season_number')
        episode = simple_info.get('episode_number')
        url = item['videourl']
        id = url.split('-')[-1]

        if season:
            seasonsurl = self.base_link + 'ajax/v2/tv/seasons/' + id
            seasonshtml = requests.get(seasonsurl).text
            match = re.compile(rf'href="#ss-episodes-(\d+)">Season\s*{season}', re.DOTALL | re.IGNORECASE).findall(seasonshtml)
            if not match:
                return
            seasonid = match[0]
            season = f'S{season}'

            episodeurl = self.base_link + 'ajax/v2/season/episodes/' + seasonid
            episodehtml = requests.get(episodeurl).text
            match = re.compile(rf'data-id="(\d+)"[^_]+?alt="Episode\s*0*{episode}"', re.DOTALL | re.IGNORECASE).findall(episodehtml)
            if not match:
                return
            id = match[0]

        serverurl = self.base_link + 'ajax/movie/episodes/' + id if '/movie/' in url else self.base_link + 'ajax/v2/episode/servers/' + id
        serverhtml = requests.get(serverurl).text

        match = re.compile(r'data-id="(\d+)".+?<span>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(serverhtml)
        if not match:
            return

        source = []
        for serverid, servername in match:
            srcurl = self.base_link + 'ajax/sources/' + serverid
            srchtml = requests.get(srcurl).text

            match = re.compile('"link":"([^"]+)"').search(srchtml)
            if match:
                link = match.group(1)
                if "rabbitstream.net" not in link:
                    continue

                link = link.split('?')[0].split('/')
                embed = link[-1]

                # common.log(f"https://uvs666.netlify.app/.netlify/functions/decrypt?id=={embed}")
                keyhtml = requests.get(f"https://uvs666.netlify.app/.netlify/functions/decrypt?id={embed}").text
                jsondata = json.loads(keyhtml)

                self.subs = []
                for track in jsondata["tracks"]:
                    if 'hun' in track["label"].lower() or 'rom' in track["label"].lower() or 'eng' in track["label"].lower():
                        self.subs.append(track["file"])

                if simple_info.get("title"):
                    release_name = f'{common.cleantext(item["title"])} ({item["year"]})'
                else:
                    release_name = f'{common.cleantext(item["title"])}: {simple_info.get("season_number").zfill(2)}x{simple_info.get("episode_number").zfill(2)} {simple_info.get("episode_title")}'

                try:
                    forbidden_chars = '"*\\/\'.|?:<>'
                    file_name = ''.join([x if x not in forbidden_chars else '_' for x in release_name]) + '.txt'
                    path = xbmcvfs.translatePath("special://subtitles")
                    if path is None or path == '':
                        path = xbmcvfs.translatePath("special://temp")
                    file_name = os.path.join(path, file_name)

                    if os.path.isfile(file_name):
                        os.remove(file_name)

                    with open(file_name, 'w') as filehandle:
                        for sub in self.subs:
                            filehandle.writelines(f"{sub}\n")
                except Exception as error:
                    common.log(error)

                videourl = jsondata["sources"][0]["file"]
                source_ = {
                    "scraper": "sflix",
                    "release_title": release_name,
                    # "info": "",
                    # "size": 0,
                    "quality": "1080p",
                    "url": videourl,
                    "debrid_provider": servername,
                    # "headers": "",
                    "filetype": "hls",
                }
                source.append(source_)
        return source

    def episode(self, simple_info, info):
        self.start_time = time.time()
        sources = []

        query = clean_title(simple_info["show_title"]).replace(' ', '-')
        try:
            results = self._make_query(query, simple_info['year'], 'TV')
            for item in results:
                source = self._process_item(item, simple_info)
                for ss in source:
                    sources.append(ss)
            return self._return_results("episode", sources)
        except PreemptiveCancellation:
            return self._return_results("episode", sources, preemptive=True)

    def movie(self, title, year, imdb, simple_info, info):
        self.start_time = time.time()
        sources = []

        year = simple_info["year"]
        query = clean_title(simple_info["title"]).replace(' ', '-')
        try:
            results = self._make_query(query, year, 'Movie')
            for item in results:
                source = self._process_item(item, simple_info)
                for src in source:
                    if src is not None:
                        sources.append(src)
            return self._return_results("movie", sources)
        except PreemptiveCancellation:
            return self._return_results("movie", sources, preemptive=True)

    @staticmethod
    def get_subs(self):
        return self.subs

    @staticmethod
    def get_listitem(return_data):
        list_item = xbmcgui.ListItem(path=return_data["url"], offscreen=True)
        list_item.setContentLookup(False)
        list_item.setProperty("isFolder", "false")
        list_item.setProperty("isPlayable", "true")

        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')

        subs = []
        forbidden_chars = '"*\\/\'.|?:<>'
        file_name = ''.join([x if x not in forbidden_chars else '_' for x in return_data.get('release_title')]) + '.txt'
        path = xbmcvfs.translatePath("special://subtitles")
        if path is None or path == '':
            path = xbmcvfs.translatePath("special://temp")
        file_name = os.path.join(path, file_name)
        if os.path.isfile(file_name):
            with open(file_name, 'r') as filehandle:
                subs = [sub.rstrip() for sub in filehandle.readlines()]
        list_item.setSubtitles(subs)

        return list_item
